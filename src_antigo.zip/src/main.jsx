import { createRoot } from "react-dom/client";
import "./index.css";
import { App } from "./App";
import "antd/dist/reset.css"; // (v5+ usa reset.css)


createRoot(document.getElementById("root")).render(<App />);
